#!/bin/bash
systemctl stop tomcat9.service
systemctl status tomcat9.service
