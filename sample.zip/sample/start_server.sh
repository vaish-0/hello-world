#!/bin/bash
systemctl start tomcat9.service
systemctl status tomcat9.service
